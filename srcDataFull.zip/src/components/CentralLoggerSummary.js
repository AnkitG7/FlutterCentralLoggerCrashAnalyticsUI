import React from 'react';

const CentralLoggerSummary = () => {
  return <h1>CentralLoggerSummary Page</h1>;
};

export default CentralLoggerSummary;
