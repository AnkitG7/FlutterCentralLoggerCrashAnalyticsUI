import React from 'react';

const CrashAnalyticsSummary = () => {
  return <h1>CrashAnalyticsSummary Page</h1>;
};

export default CrashAnalyticsSummary;
